package com.zensar.project.beans;
import java.util.Comparator;
public class EmployeeCompartor implements Comparator<Employee>{
	@Override
	public int compare(Employee e1, Employee e2) {
		return 0;
	}
}
