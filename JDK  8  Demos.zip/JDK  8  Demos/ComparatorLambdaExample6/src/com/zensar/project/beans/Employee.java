package com.zensar.project.beans;
public class Employee {
	private int empId,basicSalary;
	private String empName;
	public Employee() {}
	public Employee(int empId, int basicSalary, String empName) {
		super();
		this.empId = empId;
		this.basicSalary = basicSalary;
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", basicSalary=" + basicSalary
				+ ", empName=" + empName + "]";
	}
	
	
}
