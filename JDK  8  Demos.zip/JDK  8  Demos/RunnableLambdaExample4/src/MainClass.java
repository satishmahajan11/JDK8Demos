public class MainClass {
	public static void main(String[] args) {
		Runnable runnable = ()->{
			try{
				for(int i=1;i<=10;i++){
					Thread.sleep(1000);
					System.out.println("Tick	"+i+"	Thread	"+Thread.currentThread().getName());
				}
			}
			catch (InterruptedException e) {
				e.getMessage();	
			}
		};
		Thread th1 = new Thread(runnable, "Thread 1");
		th1.start();
		
		
		//2'nd way

		new Thread(()->{
			for(int i=1;i<=10;i++)
				System.out.println("Tick	"+i+"	Thread	"+Thread.currentThread().getName());
		}
		,"Thread 2").start();
		
		
		
		
		
		
		
	}
}