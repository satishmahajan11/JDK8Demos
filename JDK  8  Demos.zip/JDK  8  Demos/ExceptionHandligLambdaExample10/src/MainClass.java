import java.util.function.BiConsumer;
public class MainClass {
	public static void main(String[] args) {
		processArithmatic(100, 0, (n1,n2)->{
			try {
				System.out.println(n1/n2);
			} catch (ArithmeticException e) {
				e.printStackTrace();
			}
		});
	}

	
	private static void processArithmatic(int n1, int n2 , BiConsumer<Integer, Integer> consumer){
		consumer.accept(n1, n2);
	}
}