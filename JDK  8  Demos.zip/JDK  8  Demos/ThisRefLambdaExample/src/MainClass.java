public class MainClass {
	public static void main(String[] args) {
			new MainClass().mainClassInstanceMethod1();
			new MainClass().mainClassInstanceMethod2();
	}
	public void mainClassInstanceMethod1(){
		ProcessInterface ref = new ProcessInterface() {
			@Override
			public String toString() {
				return "Inner class toString()";
			}
			@Override
			public void process(int i) {
				System.out.println("Value of i "+i);
				System.out.println(this);			
			}
		};
		ref.process(100);
	}
	public void mainClassInstanceMethod2(){
		ProcessInterface ref = i ->{
				System.out.println("Value of i "+i);
				System.out.println(this);			
			};
		ref.process(100);
	}
	@Override
	public String toString() {
		return "MainClass class toString()";
	}
	
}