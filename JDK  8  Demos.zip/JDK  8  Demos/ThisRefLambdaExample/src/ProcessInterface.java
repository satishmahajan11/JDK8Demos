
public interface ProcessInterface {
	void process(int i);
}
