import com.zensar.project.lambdainterface.FunctionalInterface1;
import com.zensar.project.lambdainterface.FunctionalInterface2;
import com.zensar.project.lambdainterface.FunctionalInterface3;
import com.zensar.project.lambdainterface.FunctionalInterface4;

public class MainClass {
	public static void main(String[] args) {
		//type infrence
		FunctionalInterface1 ref1 =()->System.out.println("Hello World");
		ref1.greetUser();

		FunctionalInterface2  ref2 =(a,b) -> a+b;
		ref2.add(100, 200);


		/*FunctionalInterface3 ref3 =str -> str.toUpperCase();

		System.out.println(ref3.toUpperCase("Hello World"));*/
		
		FunctionalInterface4 ref4 =(a,b)->{
			if(a>b)return a;
			else if(b>a)return b;
			else return 0;
		};
		
	System.out.println(ref4.findGreaterNum(10, 20));

	}
}