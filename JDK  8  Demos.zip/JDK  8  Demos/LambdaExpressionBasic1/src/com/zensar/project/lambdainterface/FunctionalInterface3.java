package com.zensar.project.lambdainterface;
public interface FunctionalInterface3 {
	String toUpperCase(String str);
}