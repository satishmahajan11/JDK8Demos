package com.zensar.project.lambdainterface;
@FunctionalInterface
public interface FunctionalInterface4 {
	public int findGreaterNum(int n1, int n2);
}
