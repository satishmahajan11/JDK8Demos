
public class MainClass {
	public static void main(String[] args) {
		Thread th = new Thread(new Runnable() {
			@Override
			public void run() {
					printMessage();
			}
		});
		//1st way
		Thread th1 = new Thread(()->MainClass.printMessage());
		th1.start();
		
		Thread th2 = new Thread(()->printMessage());
		th2.start();
		
		Thread th3 = new Thread(MainClass::printMessage);
		th3.start();
		
		
		
	}
	
	public static void printMessage() {
		System.out.println("Hello World");
	}
	
}