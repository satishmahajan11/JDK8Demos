import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class MainClass {
	public static void main(String[] args) {
		method5();
	}
	public static void method1(){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
		String date = "16-Aug-2016";
		LocalDate localDate = LocalDate.parse(date,formatter);
		System.out.println(localDate);  //default, print ISO_LOCAL_DATE
		System.out.println(formatter.format(localDate));
	}
	public static void method2(){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		String date = "16/08/2016";
		LocalDate localDate = LocalDate.parse(date, formatter);
		System.out.println(localDate);
		System.out.println(formatter.format(localDate));
	}

	public static  void method3() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("E, MMM d yyyy");
		String date = "Tue, Aug 16 2016";
		LocalDate localDate = LocalDate.parse(date, formatter);
		System.out.println(localDate);
		System.out.println(formatter.format(localDate));
	}
	public static void method4(){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, MMM d, yyyy HH:mm:ss a");
		String date = "Tuesday, Aug 16, 2016 12:10:56 PM";
		LocalDateTime localDateTime = LocalDateTime.parse(date, formatter);	System.out.println(localDateTime);
		System.out.println(formatter.format(localDateTime));
	}
	
	
	public static void method5(){
		LocalDateTime currentDate = LocalDateTime.now();
		System.out.println("Before : " + currentDate);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd HH:mm:ss");
		String formatDateTime = currentDate.format(formatter);
		System.out.println("After : " + formatDateTime);
	}
}






