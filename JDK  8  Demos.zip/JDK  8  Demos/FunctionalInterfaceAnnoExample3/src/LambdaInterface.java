
@FunctionalInterface
public interface LambdaInterface {
	void method();
}
