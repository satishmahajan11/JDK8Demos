package com.zensar.project.lambdawork;
public class MainClass {
	public static void main(String[] args) {
		
		GreetingService service = (str)->System.out.println("Hello "+str);
		callForGreeting(service);
		
		callForGreeting(str->System.out.println("Hello "+str));
		
	}
	
	private static void callForGreeting(GreetingService service ){
		service.sayHello("Satish Mahajan");
	}
}