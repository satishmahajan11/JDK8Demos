package com.zensar.project.lambdawork;
public interface GreetingService {
	void sayHello(String name );
}