import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.zensar.project.beans.Employee;
public class MainClass {
	public static void main(String[] args) {
		java8WayImpl();
	}
	private static void java8WayImpl(){
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111, 12000, "Kumar"));
		empList.add(new Employee(112, 20000, "Nilesh"));
		empList.add(new Employee(113, 20000, "Rakesh"));
		empList.add(new Employee(111, 12000, "Kailash"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(113, 20000, "Raj"));


		for(int i=0;i<empList.size();i++)
			System.out.println(empList.get(i));

		for (Employee employee : empList) 
			System.out.println(employee);

		empList.forEach(employee->System.out.println(employee) );


		Collections.sort(empList, (e1,e2) ->e1.getBasicSalary()-e2.getBasicSalary());

		//print all employee details name start with 'K'

		performConditionalWork(empList, (e) -> e.getEmpName().startsWith("K"), e->System.out.println(e));

		//print all employee details name start with 'R'

		performConditionalWork(empList, (e) -> e.getEmpName().startsWith("R"),e->System.out.println(e));
	}

	private static void performConditionalWork(List<Employee>empList, Predicate<Employee> condition,Consumer<Employee> consume ){
		for (Employee employee : empList) 
			if(condition.test(employee))
				consume.accept(employee);
	}
}