

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.zensar.project.beans.Employee;
public class MainClass {
	public static void main(String[] args) {
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111, 12000, "Kumar"));
		empList.add(new Employee(112, 20000, "Nilesh"));
		empList.add(new Employee(113, 20000, "Rakesh"));
		empList.add(new Employee(111, 12000, "Kailash"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(113, 20000, "Raj"));
		
		empList.forEach(employee->System.out.println(employee));
	
	}
}
