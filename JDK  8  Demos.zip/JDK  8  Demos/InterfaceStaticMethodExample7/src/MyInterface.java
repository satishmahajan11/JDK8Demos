public  interface MyInterface {
	void sayHello();
	static  void interfaceMethod(){
		
	}
	default void sayGoodBye(){
	}
}
