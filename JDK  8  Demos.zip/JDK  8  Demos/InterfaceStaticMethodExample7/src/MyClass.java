
public class MyClass implements MyInterface {

	@Override
	public void sayGoodBye() {
	}

	@Override
	public void sayHello() {
	

	}

	
}
