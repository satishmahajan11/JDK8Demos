import java.util.ArrayList;
import com.zensar.project.beans.Employee;
public class MainClass {
	public static void main(String[] args) {
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111, 12000, "Kumar"));
		empList.add(new Employee(112, 20000, "Nilesh"));
		empList.add(new Employee(113, 20000, "Rakesh"));
		empList.add(new Employee(111, 12000, "Kailash"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(113, 20000, "Raj"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(112, 20000, "Nikesh"));

		System.out.println(empList.stream()
		.distinct()
		.filter(e ->e.getEmpName().startsWith("N")));
		
		long count =empList.stream()
		.distinct()
		.count();
		System.out.println(count  +" "+empList.size());
	}
	
}