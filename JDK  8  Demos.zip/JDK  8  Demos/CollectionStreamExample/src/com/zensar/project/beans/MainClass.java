package com.zensar.project.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class MainClass {
	public static void main(String[] args) {
		java7WayImpl();
		java8WayImpl();
	}

	private static void java7WayImpl(){
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111, 12000, "Kumar"));
		empList.add(new Employee(112, 20000, "Nilesh"));
		empList.add(new Employee(113, 20000, "Rakesh"));
		empList.add(new Employee(111, 12000, "Kailash"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(113, 20000, "Raj"));
		
		Collections.sort(empList,new Comparator<Employee>() {
			@Override
			public int compare(Employee e1, Employee e2) {
				return e1.getBasicSalary()-e2.getBasicSalary();
			}
		});

		
		
		
		//print all employee details name start with 'K'
		printEmployeeDetails(empList, new Condition() {			
			@Override
			public boolean checkNameStartWith(Employee e) {
				return e.getEmpName().startsWith("K");
			}
		});

		//print all employee details name start with 'R'
		printEmployeeDetails(empList, new Condition() {			
			@Override
			public boolean checkNameStartWith(Employee e) {
				return e.getEmpName().startsWith("R");
			}
		});


	}

	private static void java8WayImpl(){
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111, 12000, "Kumar"));
		empList.add(new Employee(112, 20000, "Nilesh"));
		empList.add(new Employee(113, 20000, "Rakesh"));
		empList.add(new Employee(111, 12000, "Kailash"));
		empList.add(new Employee(112, 20000, "Nikesh"));
		empList.add(new Employee(113, 20000, "Raj"));
		
		Collections.sort(empList, (e1,e2) ->e1.getBasicSalary()-e2.getBasicSalary());
	
		//print all employee details name start with 'K'
		
		printEmployeeDetails(empList, (e) -> e.getEmpName().startsWith("K"));
		
		printEmployeeDetails(empList, (e) -> e.getEmpName().startsWith("R"));
	}

	private static void printEmployeeDetails(List<Employee>empList, Condition condition){
		for (Employee employee : empList) {
			if(condition.checkNameStartWith(employee))
				System.out.println(employee);
		}
	}
	
	@FunctionalInterface
	private interface Condition{
		boolean checkNameStartWith(Employee e);
	}
}
